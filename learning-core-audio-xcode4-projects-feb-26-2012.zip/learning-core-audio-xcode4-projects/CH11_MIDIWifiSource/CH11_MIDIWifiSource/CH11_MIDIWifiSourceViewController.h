//
//  CH11_MIDIWifiSourceViewController.h
//  CH11_MIDIWifiSource
//
//  Created by Chris Adamson on 9/10/11.
//  Copyright 2011 Subsequently and Furthermore, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CH11_MIDIWifiSourceViewController : UIViewController

-(IBAction) handleKeyDown:(id)sender;
-(IBAction) handleKeyUp:(id)sender;

@end
